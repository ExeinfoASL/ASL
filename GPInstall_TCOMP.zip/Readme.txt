

Plugin for Exeinfo Pe


View compressed files names and compression ratio infos.


 supported files :

 - .ARC  Archives ( created with Delphi TCompress v6 by SPIS/Webcentre Ltd. )
                    http://webcentre.co.nz/compress.htm
 - .exe  GPInstall v.5.0.x by by QSC (2001.01.10) -  Stub : Borland Delphi 
                  ( http://cc.codegear.com/partners/delphi7disk1/qsc/gp_install/index.html
                    - obsolete installer )



      A.S.L - asl@onet.eu



